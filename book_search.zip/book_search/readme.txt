# Created a custom post book 
# created two taxonomies 1)publisher and 2) author for book post
# created 2 custom field of book post 1) price custom field and 2) rating custom field

1) After activate plugin you can see book post type in back-end
( here you can add manutally post data)

2)You can also see 'Book Shortcode' option at left sidebar in back-end after click on it you cas see name of custom shortcode 
from here you can copy shortcode & paste it any page or custom template

 