 jQuery(document).ready(function(){

    // PRICE SLIDER SCRIPT
     jQuery( "#slider-range" ).slider({
          range: true,
          min: 0,
          max: 3000,
          values: [ 1, 3000 ],
          slide: function( event, ui ) {
            jQuery( "#amount" ).val( "$" + ui.values[ 0 ] + " - " + ui.values[ 1 ] );
          }
     });

    jQuery( "#amount" ).val( "$" + jQuery( "#slider-range" ).slider( "values", 0 ) +
      " - " + jQuery( "#slider-range" ).slider( "values", 1 ) );
  });       
    //END

     
    


    